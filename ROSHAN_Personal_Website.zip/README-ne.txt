ROSHAN Personal Website — मोबाइलबाट प्रकाशित गर्ने निर्देशन

फाइलहरू:
- index.html : वेबसाइटको मुख्य फाइल
- song.mp3 : तपाईंले थप्नुपर्ने आफ्नै/प्रयोग गर्न अनुमति भएको गीतको फाइल
- profile.jpg : वैकल्पिक प्रोफाइल फोटो

गीत राख्ने:
1. तपाईंको आफ्नै गीत वा प्रयोग गर्न अनुमति भएको MP3 फाइललाई song.mp3 नाम दिनुहोस्।
2. index.html सँगै एउटै GitHub repository मा upload गर्नुहोस्।
3. वेबसाइटमा संगीतको Play बटन थिचेर गीत बज्छ। मोबाइल ब्राउजरले स्वतः गीत बजाउन रोक्न सक्छ।

प्रोफाइल फोटो:
index.html मा avatar section भित्रको commented <img ...> लाइनको सुरु र अन्त्यका <!-- --> हटाउनुहोस्। profile.jpg फाइल पनि upload गर्नुहोस्।

महत्त्वपूर्ण:
तपाईंले दिएको WhatsApp URL `whatsapp.com/channel/...` हो, त्यसैले यसले WhatsApp Channel खोल्छ, Group होइन।
Telegram link नदिइएकाले हाल Telegram icon ले t.me को मुख्य पृष्ठ खोल्छ। आफ्नो सही Telegram group/channel link पाएपछि index.html मा https://t.me/ लाई त्यसले बदल्नुहोस्।
वेबसाइट सार्वजनिक हुनेछ। व्यक्तिगत/गोप्य जानकारी नराख्नुहोस्।

GitHub Pages मा प्रकाशित गर्ने:
1. https://github.com मा खाता खोल्नुहोस् वा sign in गर्नुहोस्.
2. New repository बनाउनुहोस्. Repository name: roshan-links (Public).
3. Add file → Upload files बाट index.html, song.mp3 (र profile.jpg бай optional) upload गर्नुहोस्.
4. Commit changes थिच्नुहोस्.
5. Repository → Settings → Pages खोल्नुहोस्.
6. Build and deployment मा Source: Deploy from a branch छान्नुहोस्.
7. Branch: main र folder: /(root) छानेर Save गर्नुहोस्.
8. केही मिनेट पर्खेर Pages मा देखिएको Visit site link खोल्नुहोस्.
9. त्यो वेबसाइट URL TikTok → Edit profile → Website/Bio मा राख्नुहोस् (TikTok मा Website field उपलब्ध भएमा).

GitHub Pages guide: https://docs.github.com/en/pages/quickstart
